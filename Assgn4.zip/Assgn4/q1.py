# Assignment-4 Q1 - To execute run: $ python q1.py

import pandas as pd
import numpy as np
import sys

class GeneralizedContextModel:
    def __init__(self, prop_pref, scale, cat_pref):
        self.prop_pref = np.array(prop_pref)
        self.scale = scale
        self.cat_pref = np.array(cat_pref)
        self.exemplars = None
        self.labels = None

    def fit(self, X, y):
        self.exemplars = np.array(X)
        self.labels = np.array(y)

    def similarity(self, stimulus, exemplar):
        distance = np.sqrt(np.sum(self.prop_pref * (stimulus - exemplar) ** 2))
        similarity = np.exp(-self.scale * distance)
        return similarity

    def predict(self, stimuli):
        predictions = []
        for stimulus in stimuli:
            sim_scores = np.array([self.similarity(stimulus, ex) for ex in self.exemplars])
            category_scores = []
            for category in np.unique(self.labels):
                sim_sum = np.sum(sim_scores[self.labels == category])
                category_score = sim_sum * self.cat_pref[category - 1]
                category_scores.append(category_score)
            predicted_category = np.argmax(category_scores) + 1
            predictions.append(predicted_category)
        return predictions

def main(X_train, y_train):
    test_df = pd.read_csv('y.csv', header=None)
    X_test = test_df.values  
    cat_pref = [1.0, 1.0, 0.5]
    prop_pref = [1.0, 0.5]
    scale = 1.0
    gcm = GeneralizedContextModel(prop_pref=prop_pref, scale=scale, cat_pref=cat_pref)
    gcm.fit(X_train, y_train)
    predicted_categories = gcm.predict(X_test)

    with open("q1_category_response.txt", "w") as file:
        sys.stdout = file 
        print("Test Set Predictions:")
        for i, (stimulus, pred) in enumerate(zip(X_test, predicted_categories), 1):
            weight, height = stimulus
            category = {1: 'Small', 2: 'Average', 3: 'Large'}.get(pred, 'Unknown')
            print(f"Data Point {i}: Weight = {weight} kg, Height = {height} inches -> Predicted Category: {category} ({pred})")
        sys.stdout = sys.__stdout__ 

        print("Test Set Predictions:")
        for i, (stimulus, pred) in enumerate(zip(X_test, predicted_categories), 1):
            weight, height = stimulus
            category = {1: 'Small', 2: 'Average', 3: 'Large'}.get(pred, 'Unknown')
            print(f"Data Point {i}: Weight = {weight} kg, Height = {height} inches -> Predicted Category: {category} ({pred})")

if __name__ == '__main__':
    train_df = pd.read_csv('X.csv', header=None)
    X_train = train_df.iloc[:, :2].values  
    y_train = train_df.iloc[:, 2].values 
    main(X_train, y_train)
