# Assignment-4 Q2 - To execute run: $ python q2.py

import numpy as np
import pandas as pd
import csv
from collections import defaultdict
from sklearn.preprocessing import KBinsDiscretizer
import sys
import contextlib

class dLocalMAP:
    def __init__(self, c=0.5, alphas=None, n_bins=3):
        if alphas is None:
            alphas = np.ones((2, 3))
        self.c = c
        self.alpha = alphas
        self.n_bins = n_bins
        self.partition = defaultdict(list)
        self.alpha0 = np.sum(self.alpha, axis=1)
        self.N = 0
        self.discretizer = None
        self.categories = {1: 'Small', 2: 'Average', 3: 'Large'}

    def discretize_features(self, X):
        self.discretizer = KBinsDiscretizer(n_bins=self.n_bins, encode='ordinal', strategy='uniform')
        X_discrete = self.discretizer.fit_transform(X)
        return X_discrete.astype(int)

    def probClustVal(self, category, feature_index, value):
        count = len([x for x in self.partition[category] if x[feature_index] == value])
        return (count + self.alpha[feature_index][value]) / (len(self.partition[category]) + self.alpha0[feature_index])

    def condclusterprob(self, stim, category):
        pjks = []
        for i in range(len(stim)):
            pjks.append(self.probClustVal(category, i, stim[i]))
        return np.product(pjks)

    def posterior(self, stim):
        categories = list(self.partition.keys())
        pkF = np.zeros(len(categories))
        for idx, category in enumerate(categories):
            prior = self.c * len(self.partition[category]) / ((1 - self.c) + self.c * self.N)
            pF_given_k = self.condclusterprob(stim, category)
            pkF[idx] = prior * pF_given_k
        if np.sum(pkF) == 0:
            return pkF
        return pkF / np.sum(pkF)

    def fit(self, X, y):
        X_discrete = self.discretize_features(X)
        for stim, label in zip(X_discrete, y):
            self.partition[label].append(stim)
            self.N += 1

    def predict(self, X):
        X_discrete = self.discretizer.transform(X).astype(int)
        predictions = []
        for stim in X_discrete:
            posterior_probs = self.posterior(stim)
            if np.sum(posterior_probs) == 0:
                predicted_category = max(self.partition.keys(), key=lambda k: len(self.partition[k]))
            else:
                categories = list(self.partition.keys())
                predicted_category = categories[np.argmax(posterior_probs)]
            predictions.append(predicted_category)
        return predictions

def load_csv_features_labels(filepath):
    data = pd.read_csv(filepath, header=None)
    X = data.iloc[:, :2].values  
    y = data.iloc[:, 2].values.astype(int)  
    return X, y

def load_csv_features(filepath):
    data = pd.read_csv(filepath, header=None)
    X = data.iloc[:, :2].values  
    return X

def main(X_train, y_train):
    test_filepath = 'y.csv'
    model = dLocalMAP(c=0.5, alphas=np.ones((2, 3)), n_bins=3) 
    model.fit(X_train, y_train)
    X_test = load_csv_features(test_filepath)
    predictions = model.predict(X_test)

    with open("q2_category_response.txt", "w") as file:
        with contextlib.redirect_stdout(file):
            print("Test Set Predictions:")
            for i, (stimulus, pred) in enumerate(zip(X_test, predictions), 1):
                weight, height = stimulus
                category = model.categories.get(pred, 'Unknown')
                print(f"Data Point {i}: Weight = {weight} kg, Height = {height} inches -> Predicted Category: {category} ({pred})")
    
    print("Test Set Predictions:")
    for i, (stimulus, pred) in enumerate(zip(X_test, predictions), 1):
        weight, height = stimulus
        category = model.categories.get(pred, 'Unknown')
        print(f"Data Point {i}: Weight = {weight} kg, Height = {height} inches -> Predicted Category: {category} ({pred})")
    print("Output saved to file q2_category_response.txt")

if __name__ == '__main__':
    train_filepath = 'X.csv'
    X_train, y_train = load_csv_features_labels(train_filepath)
    main(X_train, y_train)
