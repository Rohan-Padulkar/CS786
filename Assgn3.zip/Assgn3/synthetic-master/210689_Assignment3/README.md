# Assignment-3 Submission
## Name: Padulkar Rohan Ravikumar
## Roll No: 210689

My submission zip file 210689_Assignmnet3.zip contains the following structure:

1) Submission for Q1: 
   - Folder: Q1
   - Contents: a) Q1.ipynb
               b) inception_v4.py
   - Make sure to have dataset folders ds1, ds2, ds3, ds4 in the same directory as these files
   - Executing the cells within the jupyter notebook Q1.ipynb will train the dataset and test it giving outputs in the cell outputs only.

2) Submission for Q2:
    - Folder: Q2
    - Contents: Subfolders: a) output/: contains ROC graphs of testing data
                            b) testing_screenshots/: contains screenshots of terminal when testing the model along with their accuracies.
                            c) training_screenshots/: contains screenshots of terminal when training the model
                            d) Q2.log : contains the logs of entire training and testing of models of the artifact.

3) Submission for Q3:
    - Folder: Q3
    - Contents: a) Q3.ipynb
    - This jupyter notebook contains solustion for Q3 where I have trained a CNN to identify alphabets on the basis of proximity between their micro object.

4) Submission for Q4:
    - Folder: Q4
    - Contents: a) 4_cnn.ipynb
                b) 4_dataset.ipynb
    - 4_dataset.ipynb file generates the dataset for the program, and 4_cnn.ipynb trains and tests the model over the data generated.

