# import os
# import shutil
# import subprocess

# # Function to run the createImage.py file and copy the output to a new folder
# def run_create_image(run_number):
#     # Execute the createImage.py script
#     subprocess.run(['python', 'createImage.py'])
    
#     # Define the source folders created by createImage.py
#     source_folders = ['ds1', 'ds2', 'ds3', 'ds4']
    
#     # Create a new folder to store the output of this run
#     destination_folder = f'r_{run_number}'
#     os.makedirs(destination_folder, exist_ok=True)
    
#     # Move each folder to the destination folder
#     for folder in source_folders:
#         if os.path.exists(folder):
#             shutil.move(folder, os.path.join(destination_folder, folder))

# # Run the script 2 times
# for i in range(1, 11):
#     run_create_image(i)


# import os
# import shutil

# # Function to copy and rename files from source to destination
# def merge_folders(source, destination):
#     # Walk through the directory structure of the source
#     for dirpath, dirnames, filenames in os.walk(source):
#         # Get the relative path from the source folder
#         relative_path = os.path.relpath(dirpath, source)
        
#         # Create the corresponding directory in the destination if it doesn't exist
#         dest_dir = os.path.join(destination, relative_path)
#         os.makedirs(dest_dir, exist_ok=True)

#         # Get the current highest numbered file in the destination folder
#         existing_files = os.listdir(dest_dir)
#         existing_indices = [int(f.split('.')[0]) for f in existing_files if f.endswith('.png')]
#         max_index = max(existing_indices, default=-1) + 1

#         # Copy each file from source to destination, renaming if necessary
#         for filename in filenames:
#             if filename.endswith('.png'):
#                 new_filename = f"{max_index}.png"
#                 src_file = os.path.join(dirpath, filename)
#                 dest_file = os.path.join(dest_dir, new_filename)
#                 shutil.copy(src_file, dest_file)
#                 max_index += 1

# # Merge r_1 to r_10 into dataset folder
# destination_folder = "dataset"
# for i in range(1, 11):
#     source_folder = f"r_{i}"
#     merge_folders(source_folder, destination_folder)

# print("Merge completed successfully!")

import os
import numpy as np
import matplotlib.pyplot as plt
import pickle
import gzip

# Modified version of packImages that does not create new folders or copy files
def pack_images_directly(dataset_path):
    # Traverse into each ds1, ds2, ds3, ds4 folder
    for ds_folder in ['ds1', 'ds2', 'ds3', 'ds4']:
        ds_path = os.path.join(dataset_path, ds_folder)
        
        # Iterate through each subfolder (like 'train', 'valid', 'train_break')
        for subdir in os.listdir(ds_path):
            subdir_path = os.path.join(ds_path, subdir)
            
            if os.path.isdir(subdir_path):
                data_x = []
                data_y = []
                
                # Iterate through each class folder (e.g., 0, 1)
                for class_folder in os.listdir(subdir_path):
                    class_folder_path = os.path.join(subdir_path, class_folder)
                    
                    if os.path.isdir(class_folder_path):
                        try:
                            # Try to convert the folder name to an integer label
                            label = int(class_folder)
                        except ValueError:
                            print(f"Skipping non-integer folder: {class_folder}")
                            continue
                        
                        # Process each image in the class folder
                        for image_file in os.listdir(class_folder_path):
                            if image_file.endswith('.png'):
                                image_path = os.path.join(class_folder_path, image_file)
                                image_data = plt.imread(image_path)
                                data_x.append(image_data.tolist())
                                data_y.append(label)
                
                # Form the .data file corresponding to the subfolder (train, valid, etc.)
                data_file = os.path.join(ds_path, subdir + '.data')
                
                # Save the .data file (gzip and pickle format)
                with gzip.open(data_file, 'wb') as f:
                    pickle.dump((data_x, data_y), f, protocol=2)
                
                print(f"Created {data_file}")

# Path to the dataset folder
dataset_folder = 'dataset'

# Generate the .data files
pack_images_directly(dataset_folder)

print("Data files generated successfully!")



