# import os
# import sys
# import numpy as np
# if sys.version_info[0] < 3:
#     import cPickle
# else:
#     import pickle
# import gzip

# import shutil
# from scipy import misc
# from sklearn import metrics
# import matplotlib.pyplot as plt
# # import pdb
# from datetime import datetime
# from keras.applications.inception_v3 import InceptionV3
# from keras.preprocessing import image
# from keras.models import Model
# from keras.layers import Dense, GlobalAveragePooling2D
# from keras import backend as K
# from keras.layers import Input
# # from keras.utils import np_utils
# from tensorflow.keras.utils import to_categorical
# from tensorflow.keras.preprocessing.image import ImageDataGenerator
# from keras.optimizers import SGD
# from keras import callbacks
# import matplotlib.pyplot as plt

# K.set_image_data_format('channels_first')

# def read_dataset(filename='alldata.data'):
#     if filename[-3:] == '.gz':
#         f = gzip.open(filename, 'rb')
#     else:
#         f = open(filename, 'rb')
#     if sys.version_info[0] < 3:
#         dataxy = cPickle.load(f)
#     else:
#         dataxy = pickle.load(f, encoding='latin1')
#     f.close()
#     return dataxy

# def save_dataset(filename='alldata.data.gz', data=None):
#     if filename[-3:] == '.gz':
#         f = gzip.open(filename, 'wb')
#     else:
#         f = open(filename, 'wb')
#     if sys.version_info[0] < 3:
#         cPickle.dump(data, f, protocol=cPickle.HIGHEST_PROTOCOL)
#     else:
#         pickle.dump(data, f, protocol=2)
#     f.close()
    
# def preprocessing_img(x):
#     x = np.asarray(x).astype(np.float32)
#     x /= 255.0
    
#     return x
    
# def evaluate(gt, p):
#     gt = np.asarray(gt)
#     p = np.asarray(p)
#     tmp = np.array([np.array([p, np.ones(len(gt),)*(1 - 1e-15)]).min(axis=0), np.ones(len(gt),)*1e-15]).max(axis=0)
#     logloss = -np.sum(gt*np.log(tmp)+(1-gt)*np.log(1-tmp))/float(len(gt))
#     return logloss
    
# def get_error(gt, p):
#     gt = np.asarray(gt)
#     p = np.asarray(p).astype(np.int8)
#     error = np.sum(np.not_equal(gt, p))
#     return float(error)/len(gt)
    
# def get_confusion_matrix(gt, p):
#     gt = np.asarray(gt)
#     p = np.asarray(p).astype(np.int8)
#     tp = np.sum(np.logical_and(gt==1, p==1))
#     tn = np.sum(np.logical_and(gt==0, p==0))
#     fp = np.sum(np.logical_and(gt==0, p==1))
#     fn = np.sum(np.logical_and(gt==1, p==0))
#     return ((tn, fp), (fn, tp))

# # Create output directory if it doesn't exist
# output_dir = "output"
# if not os.path.exists(output_dir):
#     os.makedirs(output_dir)

# # When saving plots, use timestamp and plot type for unique naming
# def save_plot(plt, plot_type):
#     timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
#     filename = f"{output_dir}/{plot_type}_{timestamp}.png"
#     plt.savefig(filename)
#     plt.close()
#     print(f"Plot saved as: {filename}")
    
# ###########################################################
# ## Fine-tune InceptionV3 on a new set of classes
# def build_inceptionV3(input_shape):
#     # this could also be the output a different Keras model or layer
#     input_tensor = Input(shape=input_shape)  # this assumes K.image_data_format() == 'channels_first'

#     # create the base pre-trained model, original input was (3, 299, 299)
#     base_model = InceptionV3(input_tensor=input_tensor, weights='imagenet', include_top=False)

#     ## let's visualize layer names and layer indices to see how many layers we should freeze:
#     # for i, layer in enumerate(base_model.layers):
#        # print(i, layer.name)
       
#     # add a global spatial average pooling layer
#     x = base_model.output
#     x = GlobalAveragePooling2D()(x)
#     # let's add a fully-connected layer
#     x = Dense(1024, activation='relu')(x)
#     # and a logistic layer -- let's say we have 200 classes
#     predictions = Dense(2, activation='softmax')(x)

#     # this is the model we will train
#     model = Model(inputs=input_tensor, outputs=predictions)
    
#     return base_model, model


# def main(argv = ['ds1', 'test.data', 'None']):
#     debug = True
#     ds = argv[0]
#     testfile = argv[1]
#     modelfile = None
#     if len(argv) > 2:
#         if argv[2] != 'None':
#             modelfile = argv[2]
    
    
#     nb_epoch2 = 70
    
#     base_model, model = build_inceptionV3(input_shape=(3,200,200))

#     if modelfile is None:
#         model_weights = ds+"_incep3-%d.hdf5"%(nb_epoch2)
#     else:
#         model_weights = modelfile
    
#     print('load weight: ',model_weights)
#     model.load_weights(model_weights)
    
#     # load testing data
#     tx, ty = read_dataset(os.path.join(ds,testfile))
#     tx = preprocessing_img(tx)
#     tx = np.asarray(tx)[:, np.newaxis, :, :]
#     tx = np.repeat(tx, 3, axis=1)
    
#     print('test on %d samples'%len(ty))
    
#     preds = model.predict(tx, verbose=0)
#     print("error:",get_error(ty, preds[:,1]>preds[:,0]))
#     print("confusion:")
#     print(get_confusion_matrix(ty, preds[:,1]>preds[:,0]))
    
#     fpr, tpr, thresholds = metrics.roc_curve(ty, preds[:,1], pos_label=1)
#     auc = metrics.auc(fpr, tpr)
#     plt.ion()
#     plt.plot(fpr, tpr)
#     plt.title('auc: '+str(auc))
#     plt.xlabel('FPR')
#     plt.ylabel('TPR')
#     # plt.show()
#     save_plot(plt, "confusion_matrix")
    
#     #----------
#     ## debug: dump error cases
#     if debug:
#         err_dump_dir = 'err_'+ds+'_'+testfile[:-len('.data')]
#         if os.path.exists(err_dump_dir):
#             shutil.rmtree(err_dump_dir)
#         os.mkdir(err_dump_dir)
        
#         os.mkdir(os.path.join(err_dump_dir, '0'))
#         os.mkdir(os.path.join(err_dump_dir, '1'))
#         n_0 = sum(np.array(ty)==0)
#         for i in range(n_0):
#             y, py = ty[i], preds[i,1]
#             if y != (py>0.5):
#                 plt.imsave(os.path.join(err_dump_dir, str(y), str(i)+'_'+str(py)+'.png'), tx[i, 0])
#         for i in range(n_0, len(ty)):
#             y, py = ty[i], preds[i,1]
#             if y != (py>0.5):
#                 plt.imsave(os.path.join(err_dump_dir, str(y), str(i-n_0)+'_'+str(py)+'.png'), tx[i, 0])
#     #----------
    
#     ## evaluate the model
#     # ty = np_utils.to_categorical(ty, 2)
#     # scores = model.evaluate(tx, ty, verbose=0)
#     # print("%s: %.2f%%" % (model.metrics_names[1], scores[1]*100))
    

# if __name__ == "__main__":
#     main(sys.argv[1:])


import os
import sys
import numpy as np
import shutil
from scipy import misc  # Note: `misc.imsave` is deprecated; consider using `imageio` or `PIL` instead
from sklearn import metrics
import matplotlib.pyplot as plt
# import pdb

from keras.applications.inception_v3 import InceptionV3
from keras.preprocessing import image
from keras.models import Model
from datetime import datetime
from keras.layers import Dense, GlobalAveragePooling2D, Input
from keras import backend as K
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from keras import callbacks

from sklearn.metrics import accuracy_score, precision_score, recall_score, classification_report

K.set_image_data_format('channels_first')

def evaluate(gt, p):
    gt = np.asarray(gt)
    p = np.asarray(p)
    tmp = np.array([np.array([p, np.ones(len(gt),)*(1 - 1e-15)]).min(axis=0), np.ones(len(gt),)*1e-15]).max(axis=0)
    logloss = -np.sum(gt*np.log(tmp)+(1-gt)*np.log(1-tmp))/float(len(gt))
    return logloss

def get_error(gt, p):
    gt = np.asarray(gt)
    p = np.asarray(p).astype(np.int8)
    error = np.sum(np.not_equal(gt, p))
    return float(error)/len(gt)

def get_confusion_matrix(gt, p):
    gt = np.asarray(gt)
    p = np.asarray(p).astype(np.int8)
    tp = np.sum(np.logical_and(gt==1, p==1))
    tn = np.sum(np.logical_and(gt==0, p==0))
    fp = np.sum(np.logical_and(gt==0, p==1))
    fn = np.sum(np.logical_and(gt==1, p==0))
    return ((tn, fp), (fn, tp))
    
# Create output directory if it doesn't exist
output_dir = "output"
if not os.path.exists(output_dir):
    os.makedirs(output_dir)

# When saving plots, use timestamp and plot type for unique naming
def save_plot(plt, plot_type):
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"{output_dir}/{plot_type}_{timestamp}.png"
    plt.savefig(filename)
    plt.close()
    print(f"Plot saved as: {filename}")

###########################################################
## Fine-tune InceptionV3 on a new set of classes
def build_inceptionV3(input_shape):
    # this could also be the output a different Keras model or layer
    input_tensor = Input(shape=input_shape)  # channels_first
    
    # create the base pre-trained model, original input was (3, 299, 299)
    base_model = InceptionV3(input_tensor=input_tensor, weights='imagenet', include_top=False)
    
    # add a global spatial average pooling layer
    x = base_model.output
    x = GlobalAveragePooling2D()(x)
    # add a fully-connected layer
    x = Dense(1024, activation='relu')(x)
    # and a logistic layer
    predictions = Dense(2, activation='softmax')(x)
    
    # this is the model we will train
    model = Model(inputs=input_tensor, outputs=predictions)
    
    return base_model, model
    

def main(argv = ['ds3', 'train_break']):
    debug = True
    ds = argv[0]
    test_subset = argv[1]  # e.g., 'test', 'test_newshape'
    modelfile = None
    if len(argv) > 2:
        if argv[2] != 'None':
            modelfile = argv[2]
    
    # Build the model architecture
    base_model, model = build_inceptionV3(input_shape=(3, 200, 200))

    if modelfile is None:
        # Find the latest model based on naming convention or specify a default
        # Here, assuming the latest epoch model is needed. Adjust as necessary.
        model_weights = f"models/ds4_incep3-10-0.986.hdf5"  # Update epoch number if different
    else:
        model_weights = modelfile
    
    print('Loading weights from:', model_weights)
    model.load_weights(model_weights)
    
    # Compile the model (required before making predictions)
    model.compile(optimizer='rmsprop', loss='categorical_crossentropy', metrics=['accuracy'])
    
    ## Define ImageDataGenerator for testing (no augmentation)
    test_datagen = ImageDataGenerator(
        preprocessing_function=None,  # No augmentation for testing
        featurewise_center=False,
        samplewise_center=False,
        featurewise_std_normalization=False,
        samplewise_std_normalization=False,
        zca_whitening=False)
    
    # Flow test images in batches using test_datagen
    test_generator = test_datagen.flow_from_directory(
        os.path.join(ds, test_subset),
        target_size=(200, 200),
        color_mode='rgb',
        batch_size=40,
        class_mode='categorical',
        shuffle=False)
    
    # Get ground truth labels
    ground_truth = test_generator.classes
    class_indices = test_generator.class_indices
    # Map class indices to labels
    inv_class_indices = {v: k for k, v in class_indices.items()}
    print("Class indices:", class_indices)
    
    # Predict using the model
    preds = model.predict(test_generator, steps=np.ceil(test_generator.samples / 40), verbose=1)
    predicted_classes = np.argmax(preds, axis=1)

    accuracy = accuracy_score(ground_truth, predicted_classes) * 100
    precision = precision_score(ground_truth, predicted_classes, average='binary') * 100
    recall = recall_score(ground_truth, predicted_classes, average='binary') * 100

    print(f"Accuracy: {accuracy:.2f}%")
    print(f"Precision: {precision:.2f}%")
    print(f"Recall: {recall:.2f}%")
    
    # Calculate error
    error_rate = np.mean(predicted_classes != ground_truth)
    print("Error rate:", error_rate)
    
    # Confusion matrix
    cm = metrics.confusion_matrix(ground_truth, predicted_classes)
    print("Confusion Matrix:")
    print(cm)
    
    # ROC Curve and AUC
    if len(np.unique(ground_truth)) == 2:
        fpr, tpr, thresholds = metrics.roc_curve(ground_truth, preds[:,1], pos_label=1)
        auc = metrics.auc(fpr, tpr)
        plt.figure()
        plt.plot(fpr, tpr, label='AUC = {:.3f}'.format(auc))
        plt.plot([0, 1], [0, 1], 'k--')  # Diagonal
        plt.title('ROC Curve')
        plt.xlabel('False Positive Rate')
        plt.ylabel('True Positive Rate')
        plt.legend(loc='lower right')
        # plt.show()
        save_plot(plt, "confusion_matrix")
    else:
        print("ROC Curve is only available for binary classification.")
    
    #----------
    ## Debug: Dump error cases
    if debug:
        err_dump_dir = f'err_{ds}_{test_subset}'
        if os.path.exists(err_dump_dir):
            shutil.rmtree(err_dump_dir)
        os.mkdir(err_dump_dir)
        
        os.mkdir(os.path.join(err_dump_dir, '0'))
        os.mkdir(os.path.join(err_dump_dir, '1'))
        
        for i in range(test_generator.samples):
            y_true = ground_truth[i]
            y_pred = predicted_classes[i]
            if y_true != y_pred:
                class_folder = str(y_true)
                # Get filename
                fname = test_generator.filenames[i]
                # Source path
                src_path = os.path.join(ds, test_subset, class_folder, fname.split('/')[-1])
                # Destination path
                dst_path = os.path.join(err_dump_dir, class_folder, f"{i}_{preds[i,1]:.4f}.png")
                # Copy the erroneous image
                shutil.copy(src_path, dst_path)
    #----------

if __name__ == "__main__":
    main()
